<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "covid_db";
 
$mysqli = new mysqli($host, $user, $pass, $db); 
?>